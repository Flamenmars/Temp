
streaming_subreddits = [
{'name': 'Soccer Streams', 'url': 'soccerstreams'},
{'name': 'MMA Streams', 'url': 'MMAStreams'},
{'name': 'NFL Streams', 'url': 'NFLStreams'},
{'name': 'NBA Streams', 'url': 'nbastreams'},
{'name': 'NCAA BBall Streams', 'url': 'ncaaBBallStreams'},
{'name': 'CFB Streams', 'url': 'CFBStreams'},
{'name': 'NHL Streams', 'url': 'NHLStreams'},
{'name': 'Puck Streams', 'url': 'puckstreams'},
{'name': 'MLB Streams', 'url': 'MLBStreams'},
{'name': 'Tennis Streams', 'url': 'TennisStreams'},
{'name': 'Boxing Streams', 'url': 'BoxingStreams'},
{'name': 'Rugby Streams', 'url': 'RugbyStreams'},
{'name': 'Motor Sports Streams', 'url': 'motorsportsstreams'},
{'name': 'WWE Streams', 'url': 'WWEstreams'},
]
